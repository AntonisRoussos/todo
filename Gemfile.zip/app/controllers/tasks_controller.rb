class TasksController < ApplicationController

  before_filter :authenticate, :only => [:edit, :update]
  before_filter :correct_user, :only => [:edit, :update]

  def new
  end

  def edit
  end

  def show
    @tasks = Task.all
    @tasks = Task.paginate :page => params[:page], :per_page =>	3
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @tasks }
    end
  end

end

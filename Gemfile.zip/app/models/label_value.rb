# Creates a Label and value for select boxes and
# forms without clearly delinieated# objects, such as Arrays.
class LabelValue
# name the accessors. Label and Value
attr_accessor :label, :value
end


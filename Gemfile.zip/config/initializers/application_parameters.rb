# Be sure to restart your server when you modify this file.

Todo::Application.config.application_locales = Dir.glob("config/locales/*")
